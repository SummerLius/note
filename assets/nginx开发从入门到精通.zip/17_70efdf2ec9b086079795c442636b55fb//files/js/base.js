var treelib={};//treelib全站全部公共JS
treelib.func={};//公共函数
treelib.action={};//公共动作
treelib.util={};//公共组件
//本地存储
treelib.func.storage = ( function () {
	var storage = window.localStorage || null;
	return {
		set: function ( key, data ) {
			if ( storage && data) {storage.setItem( key, data  ); return true;}
			return false;
		},
		get: function ( key ) {
			if ( storage ) {return storage.getItem( key );}
			return null;
		},
		remove: function ( key ) {storage && storage.removeItem( key );}
	};
})();
treelib.func.strip_tags = function (str){
  return str.replace(/<[^>]+>/g,"");//去掉所有的html标记
};
//初始化左侧菜单
treelib.util.init_left_menu = function(bar_name) {
	var lw_now = treelib.func.storage.get(bar_name);
	if (isNaN(lw_now) || !lw_now) {
		lw_now = $('.left_menu_container').width();
	}
	//tab切换
	$('.left_menu_selecte_list p').click(function() {
		$(this).addClass('left_menu_selected').removeClass('left_menu_selecte');
		$(this).siblings().addClass('left_menu_selecte').removeClass('left_menu_selected');
	});
	$('.left_menu_selecte_list p').first().click(function() {
		$('.left_menu_search').hide();
		$('.left_menu_list').show();
	});
	$('.left_menu_selecte_list p').last().click(function() {
		$('.left_menu_list').hide();
		$('.left_menu_search').show();
	});
	//最小化
	$('.left_menu_minimum').click(function() {
		$('.left_menu_container').hide();
		$('.right_book').width('93%');
		$('.left_menu_restore').show('normal');
		$('.edui-editor,#container').width($('.right_book').width() - 5);
		//重置编辑器大小
		$('.edui-editor-iframeholder').width($('.right_book').width() - 10);
		//重置编辑器大小
		$('.right_book').css('margin-left', '40px');
	});
	//最大化
	$('.left_menu_restore').click(function() {
		$('.left_menu_restore').hide();
		$('.left_menu_container').show();
		resize_width(lw_now);
		$('.right_book').css('margin-left', '20px');
	});
	//设置高度
	function resize_height() {
		var height = $(window).height() - 70;
		height = height < 400 ? 400 : height;
		$('.left_menu_container').height(height);
		$('.left_menu_data_list').height(height - 67);
		$('.drag_bar').height(height - 45);
		$('#detail_page_content iframe').height(height - 10);
	};
	//设置宽度,写到这里已经基本上已经蒙了,自己都不知道自己咋实现的了.
	function resize_width(lw) {
		if ($('.left_menu_container').css('display') == 'none') {//最小化时
			lw = 0;
		} else {
			if (lw > $(window).width() * 0.3) {
				lw = $(window).width() * 0.3;
			};
			if (lw < 200) {
				lw = 200;
			}
			$('.left_menu_container').width(lw);//左侧树宽
			$('.left_menu_data_list').width(lw - 15);
			$('.left_menu_control input').width(lw - 90);
		}
		var rw = $(window).width() - lw - 80;
		$('.right_book').width(rw);//右宽
		$('.edui-editor,#container').width(rw);//重置编辑器大小
		$('.edui-editor-iframeholder').width(rw - 5);//重置编辑器大小
	};
	//绑定左侧菜单拖拽控制宽度
	$('.drag_bar').bind('mousedown', function(e) {
		var html = '<div id="move_mask" style="opacity:0 !important;z-index:9999;background:gray;width:100%;height:' + $(window).height() + 'px;position:absolute;top:0;left:0;cursor:ew-resize;"></div>';
		$(html).insertAfter("body");
		function mouseMove(e) {
			resize_width(e.clientX);
		};
		function mouseUp() {
			$('#move_mask').remove();
			$(window).unbind("mousemove", mouseMove).unbind("mouseup", mouseUp);
			treelib.func.storage.set(bar_name, $('.left_menu_container').width());
		};
		$(window).bind("mousemove", mouseMove).bind("mouseup", mouseUp);
		e.preventDefault();
	});
	//窗口大小改变时重置大小
	$(window).resize(function() {
		resize_height();
		resize_width(lw_now);
	}).trigger("resize");
};


$(function(){
	//初始化左侧菜单
	$('.left_menu_tree_data_list').jstree({
		"core" : {
			"animation" : 150
		},
		"types" : {
			"root" : {
				"icon" : "book_index_tree_icon_root",
				"valid_children" : ["default", "folder", "file"]
			},
			"default" : {
				"icon" : "jstree-folder"
			},
			"folder" : {
				"icon" : "jstree-folder"
			},
			"file" : {
				"icon" : "jstree-file"
			}
		},
		"plugins" : ["types"],
	}).on('select_node.jstree', function(e, data) {
		var url;
		var ref = $('.left_menu_tree_data_list').jstree(true);
		var sel = ref.get_selected();
		aid = sel[0];
		if (!aid)
			return false;
		var node = ref.get_node(aid);
		if (data.node.type != 'root') {
			ref.is_open(aid) ? ref.close_node(aid) : ref.open_node(aid);
		}
		$('.right_book').html(content[aid].content);
		treelib.util.init_left_menu('book_detail_size');
	});
	//绑定搜索
	$(".left_menu_search_keyword").keyup(function(e) {
		var keyword = $(".left_menu_search_keyword").val();
		var e = e || event, keycode = e.which || e.keyCode;
		var result={};
		if (keycode == 13) {
			var count=0;
			for(var v in content){
				if(typeof content[v].title !='string')continue;
				var new_title=treelib.func.strip_tags(content[v].title);
				if(new_title.indexOf(keyword)>=0){
					result[v]={};
					result[v].id=content[v].id;
					result[v].title=new_title;
					count++;
				}else{
					if(typeof content[v].content !='string')continue;
					var new_content=treelib.func.strip_tags(content[v].content);
					console.dir(new_content);
					if(new_content.indexOf(keyword)>=0){
						result[v]={};
						result[v].id=content[v].id;
						result[v].title=new_title;
						count++;
					}
				}
			}
			if (count == 0) {
				var html = '<p>共搜到结果0条</p><ul>';
			} else {
				var html = '<p>共搜到结果' + count + '条</p><ul>';
				for (var i in result) {
					html += '<li data-id="' + result[i].id + '">' + result[i].title + '</li>';
				}
			}
			html += '</ul>';
			$('.left_menu_search_keyword_result').html(html); 
		}
	});
	//绑定点击展示搜索结果
	$(document).on("click", ".left_menu_search_keyword_result li", function() {
		var ref = $('.left_menu_tree_data_list').jstree(true);
		var sel = ref.get_selected();
		if (sel.length) {
			for (var i = 0; i < sel.length; i++) {
				$('.left_menu_tree_data_list').jstree(true).deselect_node(sel[i]);
			}
		}
		ref.select_node($(this).attr('data-id'));
		return false;
	});
	treelib.util.init_left_menu('book_detail_size');
	
});
